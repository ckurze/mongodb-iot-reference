import json
from citibikeapi.bikeapi import get_full_station_info
from aws_iot_mgt.device_management import create_things, delete_all_things

def lambda_handler(event=None, context=None):
    stations = get_full_station_info()
    create_things(stations)

    # try:
    #     ip = requests.get("http://checkip.amazonaws.com/")
    # except requests.RequestException as e:
    #     # Send some context about this error to Lambda Logs
    #     print(e)

    #     raise e

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Refresh finished",
        }),
    }
